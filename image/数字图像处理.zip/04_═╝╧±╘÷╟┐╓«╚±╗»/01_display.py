# Author: Shilong YANG

print('\n', '*' * 50,
      '''\n我想你应该懂的。\n什么？你不懂？请看实验（1）\n不想看？你想FAIL?\n
天助自助之人。\n ''',
      '*' * 50, end='')
